# BOOBA Yield Farming

This repo has the smart contracts and the front-end dDpp code for BOOBA yield farming, which is a way to build up the liquidity pool.
